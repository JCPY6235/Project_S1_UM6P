
/* 1- */
MovieLens> db.users.find({"movies.movieid":1196}).count()

/* 2- */

MovieLens> db.users.find({"movies.movieid":{$all:[260,1196,1210]}}).count()

/* ou */

MovieLens> db.users.find({$and:[{"movies.movieid":260},{"movies.movieid":1196},{"movies.movieid":1210}]}).count()

/* 3- */

db.users.find({movies:{$size:48}}).count()

/* 4- */

db.users.updateMany({},[{$set:{"num_ratings":{$size:"$movies"}}}])

/* 5- */

db.users.find({num_ratings:{$gt:90}}).count()

/* 6- */

db.users.find({"movies.timestamp":{$gt:Math.round(new Date("2001-01-01").getTime()/1000)}}).count()

/* 7- */

db.users.findOne({name:"Jayson Brad"}).movies.slice(-3)

/* 8- */

db.users.aggregate([{$match:{"name": "Tracy Edward",
"movies.movieid": 1210 }},
{ $project: { _id: 0, name: 1, occupation: 1, 
movies: { $filter: { input: "$movies", as: "movie", 
cond: { $eq: ["$$movie.movieid", 1210] } } }}},
{ $project: { name: 1, occupation: 1, "movies.movieid": 1, "movies.rating": 1 } } ])

/* 9- */

db.users.aggregate([ { $unwind: "$movies" }, { $match: { "movies.rating": 5}}, { $lookup: { from: "movies", localField: "movies.movieid", foreignField: "_id", as: "movieIf" } }, { $match: { "movieIf.title": "Untouchables, The" } }, { $group: { _id: null, count: { $sum: 1 } } }])