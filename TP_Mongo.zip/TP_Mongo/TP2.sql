/* Selection de la base*/

use MovieLens


/* Requêtes mongo db */
db.movies.renameCollection("Movies");
db.users.renameCollection("Users");


/* 1-Nombre d'utlisateurs dans la base de données*/

db.Movies.count()

/* 2-Nombre de films dans la base de données*/

db.Users.count()

/* 3- */

db.Movies.find({"Clifford Johnathan"},{_id:0, name:1, occupation:1})

/* 4- */

db.Users.find({age:{$gt:18, $lte:30}})

/* 5- */

db.Users.find(
    {occupation:{$in:["artist", "scientist"]}}
    )

    /* Ou */

db.Users.find(
    {$or:[{occupation:"artist"}, 
    {occupation:"scientist"}]}
    )

/* 6- */

db.Users.find(
    {gender:"F",occupation:"writer"}
    ).sort({age:-1}
    ).limit(10)  

/* 7- */

db.Users.find({},{occupation:1})

/* 8- */
db.Users.insert({name:"G15"})

/* 9- */

db.Users.update
(
    {name:"G15"},
    {$set:{movies:
    [
        {movieid:4,rating:4,timestamp:Math.round(new Date().getTime()/1000)
        }
    ]}
    }
)

/* 10- */

db.Users.remove({name:"G15"})

/* 11- */

db.Users.update
(
    {occupation:"programmer"},
    {$set:{occupation:"developer"},
    {multi:true}
    }
)

/* 12- */

db.Movies.find
(
    {title:{$regex:"198[0-9]"}}).count()

    /* 13- */

db.Movies.find(
    {$or:
        [
            {title:{$regex:"198[4-9]"}},
            {title:{$regex:"199[0-2]"}}
        ]
    })

/* 14- */

db.Movies.find({genres:"Horror"}).count()

/* 15- */

db.Movies.find(
    {$and:
    [
        {genres:{$regex:"Musical"}},
        {genres:{$regex:"Romance"}}
    ]
    }
).count()

 /*ou*/

 db.Movies.find(
    {
    $and:
    [
        {genres:/Musical/i},
        {genres:/Romance/i}
    ]
    }
).count()