
> **MITCHOZOUNOU Sagbo Jean-Claude** \
> **TP2 de base des données**


# Selection de la base
![Alt text](image.png)



# 1-Nombre d'utlisateurs dans la base de données

## db.movies.count()
![Alt text](image-1.png)

#  2-Nombre de films dans la base de données

## db.users.count()

![Alt text](image-2.png)


# 3- Requête qui affiche uniquement le nom et l'occupation de Clifford Jonathan.

## db.users.find({name:"Clifford Johnathan"}, {_id:0, name:1, occupation:1})

![Alt text](image-4.png)

# 4- Nombre d'utilisateurs entre 18 et 30 ans.

## db.users.find({age:{$gt:18, $lte:30}}).count()

![Alt text](image-5.png)




# 5- Nombre d'utilisateurs qui sont artistes ou scientifiques.

## db.users.find({occupation:{$in:["artist", "scientist"]}}).count()

![Alt text](image-6.png)

 #   /* Ou */

## db.users.find({$or:[{occupation:"artist"}, {occupation:"scientist"}]})

![Alt text](image-7.png)

# 6- Les dix femmes auteurs les plus agées

## db.seurs.find({gender:"F",occupation:"writer"}).sort({age:-1}).limit(10)  

![Alt text](image-8.png)

# 7- Toutes les occupations présentes dans la base de données.

## db.users.find({},{occupation:1})

![Alt text](image-9.png)

# 8- Insertion du nom GI5 dans la base de données.
## db.users.insert({name:"G15"})

![Alt text](image-10.png)
# 9- Mise à jour de l'entrée inséré précédemment.

## db.users.update({name:"G15"}, {$set:{movies:[{movieid:4,rating:4,timestamp:Math.round(new Date().getTime()/1000)}]}})

![Alt text](image-12.png)

# 10- Suspression de l'entrée de la base de donnée.

## db.users.remove({name:"G15"})
![Alt text](image-13.png)

# 11- Changement d'occupation << programmer >> en  << developper >>.

## db.users.update({occupation:"programmer"},{$set:{occupation:"developer"}},{multi:true})

![Alt text](image-14.png)

# 12- Nombre de films sortis dans les années quatre vingt.

## db.movies.find({title:{$regex:"198[0-9]"}}).count()

![Alt text](image-15.png)

# 13- Nombre de films sortis entre 1984 et 1992.

## db.movies.find({$or:[{title:{$regex:"198[4-9]"}},{title:{$regex:"199[0-2]"}}]}).count()

![Alt text](image-16.png)

# 14- Nombre de fils d'horreurs.

## db.movies.find({genres:"Horror"}).count()

![Alt text](image-17.png)

# 15- Nombre de films ayant pour type à la fois Musical et Romance.

## db.Movies.find({$and:[{genres:{$regex:"Musical"}}, {genres:{$regex:"Romance"}}]}).count()

![Alt text](image-18.png)

 # /*ou*/

 ## db.Movies.find({$and:[{genres:/Musical/i},{genres:/Romance/i}]}).count()

 ![Alt text](image-19.png)