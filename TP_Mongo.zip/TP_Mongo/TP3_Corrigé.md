
> **MITCHOZOUNOU Sagbo Jean-Claude** \
> **TP3 de base des données**



- **LECTURE**
# 1- Nombre d'utilisateurs ayant noté le film qui a pour id 1196.

## db.users.find({"movies.movieid":1196}).count()

![Alt text](image-20.png)

# 2- Nombre d'utilisateurs ayant noté tous les films de la première trilogie Star Wars(id 260,1196,1210).

## db.users.find({"movies.movieid":{$all:[260,1196,1210]}}).count()
![Alt text](image-21.png)
# /* ou */

## db.users.find({$and:[{"movies.movieid":260},{"movies.movieid":1196},{"movies.movieid":1210}]}).count()
![Alt text](image-22.png)

# 3- Nombre d'utilisateurs ayant noté exactement 48 films. 

## db.users.find({movies:{$size:48}}).count()

![Alt text](image-23.png)

# 4- Création du champ num_ratings qui indique le nombre de films que chque utlisateur a noté.

## db.users.updateMany({},[{$set:{"num_ratings":{$size:"$movies"}}}])
![Alt text](image-24.png)

# 5- Nombre d'utilisateurs ayant noté plus de 90 films. 


## db.users.find({num_ratings:{$gt:90}}).count()
![Alt text](image-25.png)

# 6- Nombre de note ayant été soumis après le 1er janvier 2001.

## db.users.find({"movies.timestamp":{$gt:Math.round(new Date("2001-01-01").getTime()/1000)}}).count()
![Alt text](image-26.png)

# 7- Les trois derniers films noté par Jayson Brad.

## db.users.findOne({name:"Jayson Brad"}).movies.slice(-3)

![Alt text](image-27.png)

# 8- 

## db.users.aggregate([{$match:{"name": "Tracy Edward","movies.movieid": 1210 }},{ $project: { _id: 0, name: 1, occupation: 1, movies: { $filter: { input: "$movies", as: "movie", cond: { $eq: ["$$movie.movieid", 1210] } } }}},{ $project: { name: 1, occupation: 1, "movies.movieid": 1, "movies.rating": 1 } } ])

![Alt text](image-33.png)


# 9- 

## db.movies.aggregate([{$match:{'title': 'Untouchables, The'}},{$lookup:{from: 'users',localField: '_id',foreignField: 'movies.movieid',as: 'users'}},{$unwind:'$users'},{$match:{'users.movies.rating': 5}},{$group:{_id: null,userCount:{ $sum: 1 }}},{$project:{'nb users': '$userCount'}}])






- **ECRITURE**

# 1 - L’utilisateur Barry Erin vient juste de voir le film Nixon, qui a pour id 14 ; il lui attribue la note de 4. Mettons à jour la base de données pour prendre en compte cette note.

![Alt text](image-56.png)

# 2 - Supprimons la note entrée par mégarde par Marquis Billie dans la base de données.

![Alt text](image-57.png)

# 3 - Modifions en une seule requête le document correspondant pour qu’il contienne ces trois genres (Animation, Children’s et Musical) sans doublon.

![Alt text](image-58.png)

![Alt text](image-59.png)