
> **MITCHOZOUNOU Sagbo Jean-Claude** \
> **TP4 de base des données**




- **REPLICATION**

# 1- Création des repertoires rs1, rs2, rs3 et arb

![Alt text](image-28.png)

# 2-, 3-, 4- (Voir terminal.)

# 5- Lancement des replicats
## Lancement de rs1
![Alt text](image-29.png)

## Lancement de rs2

![Alt text](image-30.png)

## Lancement de rs3

![Alt text](image-31.png)

# 6- Ouverture d'une nouvelle console pour la connection au serveur 27018 choisi comme serveur primaire

![Alt text](image-32.png)

# 7- Lancer le mode de réplication (initialiser replicaset):

![Alt text](image-34.png)

# 8- Rajout de chaque réplicat (en associant le “host” de notre machine).

![Alt text](image-37.png)

# 9- Vérification de la configuration de l’ensemble des serveurs.

![Alt text](image-38.png)

# 10- Arbitre

![Alt text](image-35.png)

# 11- 

![Alt text](image-39.png)

# Constat après Rs.status()

## On remarque que le serveur 27018 est primaire,le 27019 et le 27020 sont secondaires et le 30000 est Arbitre




- **Test  de  réplication**


## Importation des données

![Alt text](image-40.png)

# 1- Dans la console RS0:PRIMARY> vérifions le contenu de la BD “ MovieLens ”

![Alt text](image-41.png)
## Après simulation de panne, si on éssaie de vérifier la base de donnée

![Alt text](image-42.png)

# 2- Ouvrir une nouvelle console sur un serveur réplicat : mongo -port 27018 Dans la console mongo apparaîtra RS0:SECONDARY> désignant le serveur secondaire (réplicat).

![Alt text](image-43.png)
![Alt text](image-44.png)

# 3- La commande :use MovieLens;db. movies.count(); Retourne une erreur

![Alt text](image-45.png)

## Commande rs.secondaryOk(), puisque la commande rs.slaveOk() ne fonctionne plus; Pour resoudre le problème.

![Alt text](image-47.png)
## Test 
![Alt text](image-48.png)
# 4- Dans la console RS0:PRIMARY>, ajoutons un document ex :“{ test : 1}”

![Alt text](image-46.png)

# 5 - Dans la console RS0:SECONDARY>, vérifions son existence
![Alt text](image-49.png)


- **Test de tolérance aux pannes**

# 1 - Dans la console RS0:PRIMARY>, ajoutons un document ex “{ test : 2}” à la collection movies 

![Alt text](image-50.png)

# 2 - Tuons  le processus mongod “primaire”avec “ctrl+C” Ou dans la console RS0:PRIMARY>, taper :  
> use admin; puis  db.shutdownServer();

![Alt text](image-51.png)

# 3 -  Comportement des autres serveurs mongo.

![Alt text](image-52.png)
![Alt text](image-53.png)

# 4 - Relançons “mongo” mais avec le port du nouveau serveur primaire

![Alt text](image-54.png)

# 5 - Vérifions l’existence de notre document dans la collection movies.

![Alt text](image-55.png)